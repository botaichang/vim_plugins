## b-box.gif
![](b-box.gif)
## b-catrom.gif
![](b-catrom.gif)
## b-lanczos2.gif
![](b-lanczos2.gif)
## b-lanczos3.gif
![](b-lanczos3.gif)
## b-mitchell.gif
![](b-mitchell.gif)
## b-mix.gif
![](b-mix.gif)
## b-sample.gif
![](b-sample.gif)
